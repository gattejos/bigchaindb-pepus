__version__ = '0.8.0.dev'
__short_version__ = '0.8.dev'
