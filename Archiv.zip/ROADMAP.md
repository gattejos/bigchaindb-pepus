# BigchainDB Roadmap

We moved the BigchainDB Roadmap to the bigchaindb/org repository; see:

[https://github.com/bigchaindb/org/blob/master/ROADMAP.md](https://github.com/bigchaindb/org/blob/master/ROADMAP.md)

(We kept this file here to avoid breaking some links.)
