class TestBaseConsensusRules(object):
    pass
