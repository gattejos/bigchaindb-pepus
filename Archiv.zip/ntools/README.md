This directory contains tools for provisioning, deploying and managing a BigchainDB node (on AWS, Azure or wherever).
