# The Transaction, Block and Vote Models

This page about transaction concepts and data models was getting too big, so it was split into smaller pages. It will be deleted eventually, so update your links. Here's where you can find the new pages:

* [Transaction Concepts](https://docs.bigchaindb.com/en/latest/transaction-concepts.html)
* [Data Models (all of them)](https://docs.bigchaindb.com/en/latest/data-models/index.html)
