# Benchmarking tests

This folder contains util files and test case folders to benchmark the performance of a BigchainDB federation.