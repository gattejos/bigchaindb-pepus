# Speed Tests

This folder contains tests related to the code performance of a single node.